<?php
 $cx=mysqli_connect("localhost","root","","cecyt");
?>